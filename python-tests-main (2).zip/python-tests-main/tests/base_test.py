import pytest


@pytest.mark.usefixtures("setup")
class BaseTest:
    pass
