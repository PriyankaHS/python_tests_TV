from setuptools import setup, find_packages

setup(name="packages", packages=find_packages())
